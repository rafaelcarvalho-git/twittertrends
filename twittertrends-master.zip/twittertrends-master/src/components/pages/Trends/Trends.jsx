import './Trends.css';
import SearchTrends from '../../../components/SearchTrends/SearchTrends';
import React, {useState, useEffect} from 'react'


function Trends() {


  //var [pageNumber, setPageNumber] = useState(1); //paginacao com valor padrao de 1
  //var [search, setSearch] = useState('');
  var [fetchedData, updateFetchedData] = useState([]);
  var { info, results } = fetchedData;
  var api = 'https://esportes-and-trends.herokuapp.com/trends/2442047'; //guarda o link da api e recebe a variavel da pagina selecionada
 
  useEffect(()=>{ //espera o carregamento e carrega os dados da api, quando o pageNumber muda a api é carregada novamente
    (async function(){
        var data = await fetch(api).then(response=>response.json())
        updateFetchedData(data);
    })()
  },[api])

/*
  var display;
  if (results) {
    display = results.map((informations) => {
      var { id, image, name, status, species, gender, origin } = informations;
      return (
        */
    return (
        <section className="trends">
            <div className="title-section mx-auto text-center my-5 rounded border border-dark">
                <i class="bi bi-chat-left-text"></i>            
                <h2 className="">TRENDS MAIS COMENTADAS DO MOMENTO</h2>
            </div>


<SearchTrends />
       
        <ul id="aa" class="d-flex flex-wrap">
            <li className='mx-auto'>
                <a href="https://www.google.com.br/" class="trend btn my-3 shadow">
                Trend <span class="badge rounded-pill text-white">91542</span>
                </a>
            </li>
            <li className='mx-auto'>
                <a href="https://www.google.com.br/" class="trend btn my-3 shadow">
                Trend <span class="badge rounded-pill text-white">91542</span>
                </a>
            </li>
            <li className='mx-auto'>
                <a href="https://www.google.com.br/" class="trend btn my-3 shadow">
                Trend <span class="badge rounded-pill text-white">91542</span>
                </a>
            </li>
            <li className='mx-auto'>
                <a href="https://www.google.com.br/" class="trend btn my-3 shadow">
                Trend <span class="badge rounded-pill text-white">91542</span>
                </a>
            </li>
            <li className='mx-auto'>
                <a href="https://www.google.com.br/" class="trend btn my-3 shadow">
                Trend <span class="badge rounded-pill text-white">91542</span>
                </a>
            </li>
            <li className='mx-auto'>
                <a href="https://www.google.com.br/" class="trend btn my-3 shadow">
                Trend <span class="badge rounded-pill text-white">91542</span>
                </a>
            </li>
            <li className='mx-auto'>
                <a href="https://www.google.com.br/" class="trend btn my-3 shadow">
                Trend <span class="badge rounded-pill text-white">91542</span>
                </a>
            </li>
            <li className='mx-auto'>
                <a href="https://www.google.com.br/" class="trend btn my-3 shadow">
                Trend <span class="badge rounded-pill text-white">91542</span>
                </a>
            </li>
            <li className='mx-auto'>
                <a href="https://www.google.com.br/" class="trend btn my-3 shadow">
                Trend <span class="badge rounded-pill text-white">91542</span>
                </a>
            </li>
            <li className='mx-auto'>
                <a href="https://www.google.com.br/" class="trend btn my-3 shadow">
                Trend <span class="badge rounded-pill text-white">91542</span>
                </a>
            </li>
            <li className='mx-auto'>
                <a href="https://www.google.com.br/" class="trend btn my-3 shadow">
                Trend <span class="badge rounded-pill text-white">91542</span>
                </a>
            </li>
            <li className='mx-auto'>
                <a href="https://www.google.com.br/" class="trend btn my-3 shadow">
                Trend <span class="badge rounded-pill text-white">91542</span>
                </a>
            </li>
            <li className='mx-auto'>
                <a href="https://www.google.com.br/" class="trend btn my-3 shadow">
                Trend <span class="badge rounded-pill text-white">91542</span>
                </a>
            </li>
            <li className='mx-auto'>
                <a href="https://www.google.com.br/" class="trend btn my-3 shadow">
                Trend <span class="badge rounded-pill text-white">91542</span>
                </a>
            </li>
            <li className='mx-auto'>
                <a href="https://www.google.com.br/" class="trend btn my-3 shadow">
                Trend <span class="badge rounded-pill text-white">91542</span>
                </a>
            </li>
            <li className='mx-auto'>
                <a href="https://www.google.com.br/" class="trend btn my-3 shadow">
                Trend <span class="badge rounded-pill text-white">91542</span>
                </a>
            </li>
            <li className='mx-auto'>
                <a href="https://www.google.com.br/" class="trend btn my-3 shadow">
                Trend <span class="badge rounded-pill text-white">91542</span>
                </a>
            </li>
            <li className='mx-auto'>
                <a href="https://www.google.com.br/" class="trend btn my-3 shadow">
                Trend <span class="badge rounded-pill text-white">91542</span>
                </a>
            </li>

        </ul>

        </section>
    
    )
}

export default Trends;