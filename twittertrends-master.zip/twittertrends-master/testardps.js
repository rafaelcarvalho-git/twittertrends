
 
      var data = await fetch('https://esportes-and-trends.herokuapp.com/trends/2442047').then(response=>response.json())
      console.log(data);
  

import api from "services/twitter"

const getTrends = (countryCode = 1) => {
  return api.get(`/trends/${countryCode}`)
}

export default getTrends


const TwitterTrends = () => {

  const [country, setCountry] = useState()
  const [isLoading, setIsLoading] = useState(false)
  const [trends, setTrends] = useState([])
  const [showTrends, setShowTrends] = useState(false)

  const changeCountry = (receivedCountry) => {
    setShowTrends(false)
    
    setCountry(receivedCountry)
    setIsLoading(true)
    fetchTrends(receivedCountry).finally(() => setIsLoading(false))

    setShowTrends(true)
  }

  const fetchTrends = async (country) => {
    const { data } = await getTrends(country)

    if (data.success) {
      setTrends(data.trends)
    }
  }

  return (
 

        <CountrySelect 
          options={countryOptions} 
          country={country} 
          setCountry={changeCountry} 
        />

      {showTrends && 
        <S.TrendsContainer>
          {trends.map((trend) => (
            <TrendingTopic 
              url={trend.url} 
              key={trend.name}
              tweetVolume={trend.tweet_volume}
              name={trend.name}
            />
          ))}
        </S.TrendsContainer>
      }
